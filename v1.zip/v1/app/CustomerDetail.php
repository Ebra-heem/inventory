<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerDetail extends Model
{
    protected $fillable = ['date','customer_id','invoice_id','particular','amount','account_type','section'];
}
