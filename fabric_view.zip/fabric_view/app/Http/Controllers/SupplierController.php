<?php

namespace App\Http\Controllers;

use App\Purchase;
use App\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $suppliers=Supplier::all();
        return view('backend.supplier.index',compact('suppliers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.supplier.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>'required',
            'phone'=>'required',
            'address'=>'required',
            'status'=>'required'
        ]);
        $buyer= new Supplier();
        $buyer->name=$request->input('name');
        $buyer->phone=$request->input('phone');
        $buyer->address=$request->input('address');
        $buyer->status=$request->input('status');
        $buyer->save();
        toastr()->success('Supplier Save Successfully', 'System Says');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function show(Supplier $supplier)
    {
        $purchases = Purchase::where('supplier_id',$supplier->id)->get();
        $total = Purchase::where('supplier_id',$supplier->id)->sum('total');
        $paid = Purchase::where('supplier_id',$supplier->id)->sum('paid');
        $due = Purchase::where('supplier_id',$supplier->id)->sum('due'); 
        
        return view('backend.supplier.show',compact('supplier','purchases','total','paid','due'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function edit(Supplier $supplier)
    {
        $supplier=Supplier::find($supplier->id);
        return view('backend.supplier.edit',compact('supplier'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Supplier $supplier)
    {
        $supplier= Supplier::find($supplier->id);
        $supplier->name=$request->input('name');
        $supplier->phone=$request->input('phone');
       
        $supplier->address=$request->input('address');
        $supplier->status=$request->input('status');
        $supplier->save();
        toastr()->success('Supplier Updated Successfully', 'System Says');
        return redirect()->route('supplier.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Supplier  $supplier
     * @return \Illuminate\Http\Response
     */
    public function destroy(Supplier $supplier)
    {
        $supplier->delete();
        toastr()->success('Supplier Deleted Successfully', 'System Says');
        return redirect()->route('supplier.index');
    }

    public function allDues()
    {
        
        $purchases=Purchase::where('status',0)->orderby('id','desc')->get();
        $all_due= DB::table('purchases')->sum('due');

        return view('backend.supplier.all_dues',compact('purchases','all_due'));
    }
}
