

<?php $__env->startSection('extra-css'); ?>

<style>
    .invoice-box {
  max-width: 800px;
  margin: auto;
  padding: 30px;
  border: 1px solid #eee;
  box-shadow: 0 0 10px rgba(0, 0, 0, .15);
  font-size: 16px;
  line-height: 24px;
  font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
  color: #555;
}

.invoice-box table {
  width: 100%;
  line-height: inherit;
  text-align: left;
}

.invoice-box table td {
  padding: 5px;
  vertical-align: top;
}

.invoice-box table tr td:nth-child(n+2) {
  text-align: right;
}

.invoice-box table tr.top table td {
  padding-bottom: 20px;
}

.invoice-box table tr.top table td.title {
  font-size: 45px;
  line-height: 45px;
  color: #333;
}

.invoice-box table tr.information table td {
  padding-bottom: 40px;
}

.invoice-box table tr.heading td {
  background: #eee;
  border-bottom: 1px solid #ddd;
  font-weight: bold;
}

.invoice-box table tr.details td {
  padding-bottom: 20px;
}

.invoice-box table tr.item td{
  border-bottom: 1px solid #eee;
}

.invoice-box table tr.item.last td {
  border-bottom: none;
}

.invoice-box table tr.item input {
  padding-left: 5px;
}

.invoice-box table tr.item td:first-child input {
  margin-left: -5px;
  width: 100%;
}

.invoice-box table tr.total td:nth-child(2) {
  border-top: 2px solid #eee;
  font-weight: bold;
}

.invoice-box input[type=number] {
  width: 60px;
}

@media  only screen and (max-width: 600px) {
  .invoice-box table tr.top table td {
      width: 100%;
      display: block;
      text-align: center;
  }
  
  .invoice-box table tr.information table td {
      width: 100%;
      display: block;
      text-align: center;
  }
}

/** RTL **/
.rtl {
  direction: rtl;
  font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
}

.rtl table {
  text-align: right;
}

.rtl table tr td:nth-child(2) {
  text-align: left;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
          <tr class="top">
            <td colspan="5">
              <table>
                <tr>
                  <td class="title">
                   
                    <img src="https://i.ibb.co/41qtmG2/fvl.jpg" style=" max-width:150px;">
                  </td>
      
                  <td>
                    Invoice #: <?php echo e($invoice->id); ?><br> Created: <?php echo e($invoice->created_at); ?><br> Date: <?php echo e($invoice->date); ?>

                  </td>
                </tr>
              </table>
            </td>
          </tr>
      
          
              <tr class="information">
                <td colspan="5">
                  <table>
                    <tr>
                      <td>
                       Fabiric View<br> Uttar Badda, Dhaka<br> Bangladesh
                      </td>
                      <td>
                        Customer Info<br> Name:  <?php echo e($invoice->suppliers->name); ?><br> Address: <?php echo e($invoice->suppliers->address); ?>

                       </td>
                      
                    </tr>
                  </table>
                </td>
              </tr>
            
           
          
          
      
          <tr>
            <td colspan="4">
              Payment Status: <?php if($invoice->status==1): ?>
              <span class="badge badge-success">Paid</span>
              <?php else: ?>
              <span class="badge badge-danger">Due</span>
              <?php endif; ?>
            </td>
          </tr>
      
         
      
          <tr class="heading">
            <td>
              Product Name
            </td>
      
          
      
            <td>
              Quantity
            </td>
      
            <td>
              Price
            </td>
            <td>
                Total
            </td>
          </tr>
      <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $product =\App\Product::where('id', '=',$item->product_id)->first();
  ?>
          <tr class="item">
            <td>
              <?php echo e($product->code); ?>-<?php echo e($product->name); ?>

            </td>
      
           
      
            <td>
                <?php echo e($item->purchase_qty); ?>/<?php echo e($product->unit); ?>

            </td>
      
            <td>
                <?php echo e($item->buy_price); ?>

            </td>
            <td>
                <?php echo e($item->purchase_qty * $item->buy_price); ?>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <tr class="total">
            <td colspan="4"></td>
      
            <td>
              Total: <?php echo e($invoice->total); ?>

            </td>
          </tr>
      
          <tr class="item">
            <td colspan="4"></td>
      
            <td>
              Paid: <?php echo e($invoice->paid); ?>

            </td>
          </tr>
          
          <tr class="item">
            <td colspan="4"></td>
      
            <td>
              Due: <?php echo e($invoice->total-$invoice->paid); ?>

            </td>
          </tr>
          
        </table>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script src="<?php echo e(asset('admin/assets/js/autocal/jautocalc.js')); ?>"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('admin/assets/js/autocal/script.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/purchase/purchase_details.blade.php ENDPATH**/ ?>