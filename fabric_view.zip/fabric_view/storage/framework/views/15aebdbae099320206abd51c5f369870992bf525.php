<div>
    <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                        <a href="index.html"> <img alt="image" src="<?php echo e(asset('admin/')); ?>/assets/img/logo.png" class="header-logo" /> <span
                class="logo-name">Inventory</span>
            </a>
            </div>
            <ul class="sidebar-menu">
                        <li class="menu-header">Main</li>
                        <li class="dropdown active">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="briefcase"></i><span>Settings</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('supplier.index')); ?>"><i class="fas fa-users"></i>Supplier Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('customer.index')); ?>"><i class="fas fa-users"></i>Customer Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('rack.index')); ?>"><i class="fas fa-cubes"></i>Rack Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('product.index')); ?>"><i class="fas fa-cart-plus"></i>Product Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('wirehouse.index')); ?>"><i class="fas fa-cubes"></i>Wirehouse Manage</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Purchase</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('purchase.index')); ?>">Purchase Manage</a></li>
                                
                                <li><a class="nav-link" href="<?php echo e(route('stock.index')); ?>">Stock  Manage</a></li>
                              
                            </ul>
                        </li>
                        <li class="menu-header">Shoroom and Sales</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Stock and Sales</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('invoice.index')); ?>"><i class="fas fa-cart-plus"></i>Sales Invoice</a></li>
                            </ul>
                        </li>
                     
                        <li class="menu-header">Report Section</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Reports</span></a>
                            <ul class="dropdown-menu">
                            <li><a class="nav-link" href="<?php echo e(route('sales.allsales')); ?>">All Sales Reports</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('customer.all_dues')); ?>">Customer Dues List</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('supplier.all_dues')); ?>">Supplier Dues List</a></li>
                                
                            </ul>
                        </li>

                        <li class="menu-header">Employee & Attendance</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Employee</span></a>
                            <ul class="dropdown-menu">
                            <li><a class="nav-link" href="<?php echo e(route('employee.index')); ?>">Employee Manage</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('customer.all_dues')); ?>">Customer Dues List</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('invoice.sale')); ?>">Manage Comapny Invoice</a></li>
                                
                            </ul>
                        </li>

                        <li class="menu-header">Adminastration Section</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Users</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('users.index')); ?>">Manage Users</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('roles.index')); ?>">Manage Role</a></li>
                                
                            </ul>
                        </li>         
            </ul>
     </aside>
</div><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/components/backend/sidebar.blade.php ENDPATH**/ ?>