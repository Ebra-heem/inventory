
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->

    <section class="section">
        <div class="section-body">
           <div class="row">
               <div class="col-md-4">
                <div class="card border-light mb-3">
                    <div class="card-header">Supplier Information</div>
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($supplier->name); ?></h5>
                      <p class="card-text ">
                          Phone: <?php echo e($supplier->phone); ?><br>
                        Address: <?php echo e($supplier->address); ?><br>
                        Created At: <?php echo e($supplier->created_at); ?><br>
                    </p>
                    </div>
                </div>
                <div class="card border-light mb-3">
                    <div class="card-header">Transaction Information</div>
                    <div class="card-body">
                      <p>Total Payable Amount: <span class="badge badge-info"><?php echo e($total); ?></span></p>
                      <p>Total Paid Amount: <span class="badge badge-success"><?php echo e($paid); ?></span></p>
                      <p>Total Due Amount: <span class="badge badge-danger"><?php echo e($due); ?></span></p>
                    </div>
                </div>
               </div>
               <div class="col-md-8">
                <div class="card border-light mb-3">
                    <div class="card-header">Purchase Information</div>
                <?php if(count($purchases)>0): ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Product</th>
                                    
                                    <th>Purchase Qty</th>
                                    <th>Cost Price</th>
                                    <th>Total Amount</th>
                                    <th>Paid</th>
                                    <th>Due</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($product->date); ?></td>
                                <td><?php echo e($product->products->code); ?>-[<?php echo e($product->products->name); ?>]</td>
                                
                                <td><?php echo e($product->purchase_qty); ?></td>
                                <td><?php echo e($product->buy_price); ?></td>
                                <td><?php echo e($product->total); ?></td>
                                <td><?php echo e($product->paid); ?></td>
                                <td><?php echo e($product->due); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
               </div>
            </div>
            </div>
           </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
 
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.print.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/js/page/datatables.js"></script>
 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/supplier/show.blade.php ENDPATH**/ ?>