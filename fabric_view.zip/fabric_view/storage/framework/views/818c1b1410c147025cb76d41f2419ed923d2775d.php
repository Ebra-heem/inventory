

<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <h1 class="text-center">Invoice Update</h1>
    </div>
    <div class="card-body">
      <form action="<?php echo e(route('invoice.update',$invoice->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
      <div class="row">
        <div class="col-4">
          Total Bill Amount: <?php echo e($invoice->total); ?>/- <br>
          Previous Paid Amount: <?php echo e($invoice->paid); ?>/- <br>
          Previous Due Amount: <?php echo e($invoice->due); ?>/- <br>
          Last Payment Date: <?php echo e($invoice->updated_at); ?> <br>
      </div>
    
      <div class="col-4">
        <label for="paid">Paid</label>
        <input type="number" class="form-control" name="paid" id="paid">
      </div>
      <div class="col-1">
        <label for="paid"></label>
        <input type="submit" class="btn btn-info form-control" value="SAVE">
      </div>
      
      </div>
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/invoice/edit.blade.php ENDPATH**/ ?>