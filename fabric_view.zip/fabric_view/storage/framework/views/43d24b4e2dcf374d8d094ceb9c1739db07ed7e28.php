
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->

    <section class="section">
        <div class="section-body">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item"><a href="#">Library</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Data</li>
                </ol>
              </nav>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                        <p> Purchase & Stock Information</p>
                        <br>
                        <h3 class="text-center">Total Purchase Qty: <?php echo e($total_purchase_qty); ?></h3>
                        
                        </div>
                        
                        <?php if(count($purchases)>0): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Supplier</th>
                                            <th>Purchase Qty</th>
                                            <th>Price</th>
                                            <th>Purchase Due</th>
                                            <th>Status</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td><?php echo e($product->date); ?></td>
                                        <td><?php echo e($product->products->code); ?></td>
                                        <td><?php echo e($product->products->name); ?></td>
                                        <td><?php echo e($product->suppliers->name); ?></td>
                                        <td><?php echo e($product->purchase_qty); ?></td>
                                        <td><?php echo e($product->buy_price); ?></td>
                                        <td><?php echo e($product->due); ?></td>
                                        <td><?php
                                        if($product->status==1){
                                            echo "<b class='badge badge-pill badge-success mb-1'>Paid</b>";
                                        }else{
                                            echo "<b class='badge badge-pill badge-danger mb-1'>Due</b>";
                                        }
                                        ?></td>
                                       
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>
                       
                    </div>
                </div>

                
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
 
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.print.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/js/page/datatables.js"></script>

 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/purchase/showroom.blade.php ENDPATH**/ ?>