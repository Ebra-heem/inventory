


<?php $__env->startSection('content'); ?>
<div class="card card-primary">
<form action="<?php echo e(route('rack.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
      <div class="card-header">
        <h4>Rack Create</h4>
      </div>
      <div class="card-body pb-0">
        <div class="form-group">
          <label>Rack No</label>
          <div class="input-group">
            
            <input type="text" name="rack_no" class="form-control <?php $__errorArgs = ['rack_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             placeholder="Rack No">
            <?php $__errorArgs = ['rack_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group">
            <label>Wirehouse</label>
            <div class="input-group">
             <select name="wirehouse_id" class="form-control">
               <?php $__currentLoopData = $wirehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
                
             </select>
            </div>
          </div>
      </div>
      <div class="card-footer pt-">
        <button type="submit" class="btn btn-success"> <i class="fas fa-check"></i> Save</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/rack/create.blade.php ENDPATH**/ ?>