
<?php $__env->startSection('extra-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                        
                        <p>Stock List</p>
                        </div>
                        <?php if(count($stocks)>0): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                                    <thead>
                                        <tr>
                                            
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Wirehouse Qty</th>
                                            <th>Showroom Qty</th>
                                            <th>Sale Qty</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                        <td><?php echo e($product->products->code); ?></td>
                                        <td><?php echo e($product->products->name); ?></td>
                                        
                                        <td><?php echo e($product->wh_qty); ?> (<?php echo e($product->products->unit); ?>)</td>
                                        <td><?php echo e($product->sr_qty); ?></td>
                                        <td><?php echo e($product->sale_qty); ?></td>
                                       
                                        
                                        <td>
                                            <a href="<?php echo e(route('stock.show',$product->id)); ?>" class="btn btn-warning">Transfer <i class="fas fa-redo"></i> Showroom</a>
                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
 
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.print.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/js/page/datatables.js"></script>

 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/stock/index.blade.php ENDPATH**/ ?>