<div>
    <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                        <a href="index.html"> <img alt="image" src="<?php echo e(asset('admin/')); ?>/assets/img/logo.png" class="header-logo" /> <span
                class="logo-name">Otika</span>
            </a>
            </div>
            <ul class="sidebar-menu">
                        <li class="menu-header">Main</li>
                        <li class="dropdown active">
                            <a href="<?php echo e(route('home')); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="briefcase"></i><span>Settings</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('supplier.index')); ?>">Supplier Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('buyer.index')); ?>">Buyer Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('vendor.index')); ?>">Vendor Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('product.index')); ?>">Product Manage</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('wirehouse.index')); ?>">Wirehouse Manage</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Purchase</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('productbuy.index')); ?>">Product Buy</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('productbuy.manage')); ?>">Manage Product Buy</a></li>
                            </ul>
                        </li>
                        <li class="menu-header">Inventory and Collection Section</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Stock and Sales</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('stockin.index')); ?>">Stock and Sales(B2C)</a></li>
                                <li><a class="nav-link" href="<?php echo e(route('stockout.index')); ?>">Delivery Products(B2B)</a></li>  
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Collection</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('collection.index')); ?>">Manage Collection</a></li>
                            </ul>
                        </li>

                        <li class="menu-header">Account Section</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Income</span></a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(route('income.index')); ?>">Manage Income</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Expense</span></a>
                            <ul class="dropdown-menu">
                            <li><a class="nav-link" href="<?php echo e(route('expense.index')); ?>">Manage Expense</a></li>
                            </ul>
                        </li>
                        <li class="menu-header">Invoice Section</li>
                        <li class="dropdown">
                            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Invoice</span></a>
                            <ul class="dropdown-menu">
                            <li><a class="nav-link" href="<?php echo e(route('invoice.index')); ?>">Manage Commission Invoice</a></li>
                            <li><a class="nav-link" href="<?php echo e(route('invoice.sale')); ?>">Manage Comapny Invoice</a></li>
                                
                            </ul>
                        </li>
            </ul>
     </aside>
</div><?php /**PATH C:\xampp\htdocs\SIHS\resources\views/components/backend/sidebar.blade.php ENDPATH**/ ?>