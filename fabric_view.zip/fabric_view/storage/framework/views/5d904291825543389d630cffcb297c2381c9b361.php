
<?php $__env->startSection('extra-css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->

    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                        <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-success ">Today Sales</a>

                            <div class="ml-5">
                                <form class="form-inline" action="<?php echo e(route('sales.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group mb-2 ml-2">
                                        <label>From Date</label>
                                        <div class="input-group">
                                          
                                          <input id="datepicker"  data-date-format="dd/mm/yyyy" name="from" value="<?php echo e($today->format('d/m/Y')); ?>"  class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                          <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group mb-2 ml-2">
                                        <label>To Date</label>
                                        <div class="input-group">
                                          
                                          <input id="datepicker"  data-date-format="dd/mm/yyyy" name="to" value="<?php echo e($today->format('d/m/Y')); ?>"  class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                          <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary mb-2">Search</button>
                                </form>
                            </div>
                        </div>
                        
                        <hr>
                        <?php if(isset($from)): ?>
                        <div class="card-body">
                            <center>From <?php echo e($from->format('d/m/Y')); ?> to <?php echo e($to->format('d/m/Y')); ?></center>
                        </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <div class="row">
                            
                                <div class="col-4">
                                    <?php if(isset($all_sales)): ?>
                                <h4 class="text-info">Total Sales: <?php echo e($all_sales); ?></h4>
                                <?php endif; ?>
                                </div>
                                <div class="col-4">
                                    <?php if(isset($all_sales)): ?>
                                    <h4 class="text-success" >Total Paid: <?php echo e($all_paid); ?></h4>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-4">
                                    <?php if(isset($all_due)): ?>
                                    <h4 class="text-danger">Total Due: <?php echo e($all_sales-$all_paid); ?></h4>
                                    <?php endif; ?>
                                </div>
                                
                            </div>
                        </div>
                        
                        <hr>
                        <?php if(count($sales)>0): ?>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th># Invoice No</th>
                                            
                                            <th>Customer</th>

                                            <th>Total</th>
                                            <th>Paid</th>
                                            <th>Due</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td>#00<?php echo e($invoice->id); ?></td>
                                      
                                       
                                        <td><?php echo e($invoice->customers->name); ?></td>
                                        <td><?php echo e($invoice->total); ?></td>
                                        <td><?php echo e($invoice->paid); ?></td>
                                        <td><?php echo e($invoice->due); ?></td>
                                        
                                        <?php if($invoice->status==1): ?>
                                        <td class="badge badge-success">Paid</td>
                                        <?php else: ?>
                                        <td class="badge badge-danger">Due</td>
                                        <?php endif; ?>
                                        
                                        <td>
                                            <a href="<?php echo e(url('/invoice-details',$invoice->id)); ?>" class="btn btn-md btn-warning"><i class="fas fa-print"></i>Print</a>
                                            <a href="<?php echo e(route('invoice.edit',$invoice->id)); ?>" class="btn btn-md btn-info"><i class="fas fa-eye"></i>Edit</a>
                                            
                                            <?php echo Form::open(['method' => 'DELETE','route' => ['invoice.destroy', $invoice->id],'style'=>'display:inline']); ?>

                                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger fas fa-trash']); ?>

                                             <?php echo Form::close(); ?>

                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra-js'); ?>
 
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/datatables.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/dataTables.buttons.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.flash.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/jszip.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/pdfmake.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/vfs_fonts.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/bundles/datatables/export-tables/buttons.print.min.js"></script>
  <script src="<?php echo e(asset('admin/')); ?>/assets/js/page/datatables.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>


 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/sales/index.blade.php ENDPATH**/ ?>