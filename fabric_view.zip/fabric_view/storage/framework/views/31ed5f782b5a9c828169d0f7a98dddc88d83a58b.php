

<?php $__env->startSection('content'); ?>
<div class="card card-primary">
<form action="<?php echo e(route('purchase.update',$purchase->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PUT')); ?>

     
      <div class="card-body pb-0">
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label>Date</label>
              <div class="input-group">
                
                <input id="datepicker"  data-date-format="dd/mm/yyyy" name="date" value="<?php echo e($today->format('d/m/Y')); ?>"  class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>Supplier Name</label>
              <div class="input-group">
                <select name="supplier_id" id="supplier_id" value="<?php echo e(old('supplier_id')); ?>" class="form-control  <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  
                  <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($supplier->id); ?>" <?php if($purchase->supplier_id ==$supplier->id): ?>
                      selected
                  <?php endif; ?>><?php echo e($supplier->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label>Product Name</label>
              <div class="input-group">
                <select name="product_id" class="form-control product <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <option></option>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($product->id); ?>" <?php if($purchase->product_id==$product->id): ?>
                      selected
                  <?php endif; ?>><?php echo e($product->code); ?> <?php echo e($product->name); ?> -[unit: <?php echo e($product->unit); ?>]</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
          
        </div>
        <div class="row">   
          <div class="col-md-4">
            <div class="form-group">
              <label>Purchase Qty</label>
              <div class="input-group">
                <input type="text" name="purchase_qty" id="qty" value="<?php echo e($purchase->purchase_qty); ?>"  class="form-control">
    
              </div>
            </div>
          </div> 
          <div class="col-md-4">
            <div class="form-group">
              <label>Cost Price</label>
              <div class="input-group">
                <input type="text" name="buy_price" id="price" value="<?php echo e($purchase->buy_price); ?>"  class="form-control ">
               
              </div>
            </div>
          </div>  
          <div class="col-md-4">
            <div class="form-group">
              <label>Total</label>
              <div class="input-group">
                <input type="text" name="total" id="total"  value="<?php echo e($purchase->total); ?>"   class="form-control ">
                
              </div>
            </div>
          </div>
           
        </div>
        <div class="row">
           
          <div class="col-md-4">
            <div class="form-group">
              <label>Sell Price</label>
              <div class="input-group">
                <input type="text" name="sell_price" id="sell_price" value="<?php echo e($purchase->sell_price); ?>"   class="form-control ">
                
              </div>
            </div>
          </div>  
          <div class="col-md-4">
            <div class="form-group">
              <label>Paid </label>
              <div class="input-group">
                <input type="text" name="paid" id="paid" value="<?php echo e($purchase->paid); ?>"  class="form-control">
            
              </div>
            </div>
          </div>  
          <div class="col-md-4">
            <div class="form-group">
              <label>Due </label>
              <div class="input-group">
                <input type="text" name="due" id="due" value="<?php echo e($purchase->due); ?>"  class="form-control">
              </div>
            </div>
          </div> 
          <div class="col-md-4">
            <div class="form-group">
              <label>Wirehouse </label>
              <div class="input-group">
                <select name="wirehouse_id" class="form-control wirehouse <?php $__errorArgs = ['wirehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  
                  <?php $__currentLoopData = $wirehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wirehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($wirehouse->id); ?>" <?php if($purchase->wirehouse_id==$wirehouse->id): ?>
                      selected
                  <?php endif; ?>><?php echo e($wirehouse->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['wirehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>Rack No </label>
              <div class="input-group">
                <select name="rack_id" class="form-control rack <?php $__errorArgs = ['rack_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
               
                  <?php $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($rack->id); ?>" <?php if($purchase->rack_id==$rack->id): ?>
                      selected
                  <?php endif; ?>><?php echo e($rack->rack_no); ?>[<?php echo e($rack->wirehouse->name); ?>]</option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['wirehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="form-group">
              <label>Note</label>
              <div class="input-group">
               <textarea name="note" class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30" rows="10"><?php echo e($purchase->note); ?></textarea>
               <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
                   <strong><?php echo e($message); ?></strong>
               </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
            </div>
            </div>
          </div>
  
        </div>
      </div>
      <div class="card-footer pt-">
        <button type="submit" class="btn btn-success"> <i class="fas fa-check"></i> Update</button>
        
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<script>
  $(document).ready(function(){
    $('#paid').on("keyup",function(){
      var total= $('#total').val();
      var paid= $('#paid').val();
      var due= total-paid;
      $('#due').val(due);
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fabric_view\resources\views/backend/purchase/edit.blade.php ENDPATH**/ ?>